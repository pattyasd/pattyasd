package com.accenture.tcf.java.abstraction;

public interface Activity {

	public abstract void eat();

}