package com.accenture.tcf.java.abstraction;

public class Dog extends Animal {

	@Override
	public void eat() {
		System.out.println("Dog is eating pellets.");

	}

}
