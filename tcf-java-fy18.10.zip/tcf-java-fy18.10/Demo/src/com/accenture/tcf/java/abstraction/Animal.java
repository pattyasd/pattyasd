package com.accenture.tcf.java.abstraction;

public abstract class Animal implements Activity {

}
