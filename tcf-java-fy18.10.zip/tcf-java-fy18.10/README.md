## tcf-java-fy18.10
delete coding assessment folder



