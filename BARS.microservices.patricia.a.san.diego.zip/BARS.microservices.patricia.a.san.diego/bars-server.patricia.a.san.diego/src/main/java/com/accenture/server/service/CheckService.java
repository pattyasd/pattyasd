package com.accenture.server.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.json.JSONException;

@Path("/checker")
public class CheckService {
	@GET
	@Path("/check")
	public String getIfUp() throws JSONException {
		return "up";
	}
}
