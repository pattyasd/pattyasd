package com.accenture.server.service;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.server.domain.Billing;
import com.accenture.server.domain.BillingRepository;
import com.accenture.server.domain.Customer;
import com.accenture.server.domain.CustomerRepository;
import com.accenture.server.domain.Request;
import com.accenture.server.domain.RequestRepository;

@Path("/barsprocessing")
public class ProcessService {

	@Autowired
	private RequestRepository reqRepo;

	@Autowired
	private BillingRepository billingRepo;

	@Autowired
	private CustomerRepository customerRepo;

/*	@PersistenceContext
	EntityManager em;*/

	// http://localhost:8080/barsprocessing/insertdata
	@POST
	@Path("/insertdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response insertData(String reqdata) {
		JSONArray array;

		try {
			array = new JSONArray(reqdata);
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			for (int i = 0; i < array.length(); i++) {
				JSONObject json = array.getJSONObject(i);
				int billing = json.getInt("billing");

				Date start = format.parse(json.getString("startDate"));
				Date end = format.parse(json.getString("endDate"));
				java.sql.Date startdate = new java.sql.Date(start.getTime());
				java.sql.Date enddate = new java.sql.Date(end.getTime());

				System.out.println(json.getString("startDate"));
				Request request = new Request(billing, startdate, enddate);
				reqRepo.save(request);

			}
			JSONObject jsonResponse = new JSONObject();
			jsonResponse.put("Info", "Request completed!");

			return Response.status(200).entity(jsonResponse.toString())
					.type(MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			JSONObject jsonResponse = new JSONObject();
			e.printStackTrace();
			return Response.status(400).entity(jsonResponse.toString())
					.type(MediaType.APPLICATION_JSON).build();

		}
	}

	// http://localhost:8080/barsprocessing/registercustomer
	@POST
	@Path("/registercustomer")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response registerCustomer(String customer) {

		try {
			JSONObject json = new JSONObject(customer);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			java.util.Date dc = sdf.parse(json.getString("dateCreated"));
			Date dateCreated = new Date(dc.getTime());

			String firstName = json.getString("firstName");
			String lastName = json.getString("lastName");
			String address = json.getString("address");
			String status = json.getString("status");
			String lastEdited = json.getString("lastEdited");

			Customer c = new Customer(firstName, lastName, address, status,
					dateCreated, lastEdited);

			customerRepo.save(c);

			JSONObject jsonresponse = new JSONObject();

			jsonresponse.put("INFO", "Registered Successfully");

			return Response.status(200).entity(jsonresponse.toString())
					.type(MediaType.APPLICATION_JSON).build();

		} catch (JSONException | java.text.ParseException e) {
			e.printStackTrace();
			JSONObject jsonresponse = new JSONObject();
			return Response.status(400).entity(jsonresponse.toString())
					.type(MediaType.APPLICATION_JSON).build();

		}
	}

	// http:localhost:8080/barsprocessing/viewrequest
	@POST
	@Path("/viewrequest")
	@Produces(MediaType.APPLICATION_JSON)
	public Response viewRequest() throws JSONException {

		JSONObject json = null;
		JSONArray array = new JSONArray();
		List<Request> reqList = reqRepo.findAll();

		for (Request request : reqList) {
			json = new JSONObject();
			json.put("requestId", request.getRequestId());
			json.put("billingCycle", request.getBillingCycle());
			json.put("startDate", request.getStartDate());
			json.put("endDate", request.getEndDate());
			array.put(json);
		}

		return Response.status(200).entity(array.toString())
				.type(MediaType.APPLICATION_JSON).build();
	}

	// http:localhost:8080/barsprocessing/viewbilling
	@GET
	@Path("/viewbilling")
	@Produces(MediaType.APPLICATION_JSON)
	public Response viewBilling() throws JSONException {
		List<Request> request = reqRepo.findAll();
		JSONObject json = null;
		JSONArray array = new JSONArray();

		for (Request req : request) {
			Billing billing = billingRepo
					.findByBillingCycleAndStartDateAndEndDate(
							req.getBillingCycle(), req.getStartDate(),
							req.getEndDate());
			if (billing == null) {
				return Response.status(200).entity(null)
						.type(MediaType.APPLICATION_JSON).build();
			}
			json = new JSONObject();
			json.put("billingCycle", billing.getBillingCycle());
			json.put("startDate", billing.getStartDate());
			json.put("endDate", billing.getEndDate());
			json.put("amount", billing.getAmount());
			json.put("firstName", billing.getAccount().getCustomer()
					.getFirstName());
			json.put("lastName", billing.getAccount().getCustomer()
					.getLastName());
			array.put(json);
		}
		return Response.status(200).entity(array.toString())
				.type(MediaType.APPLICATION_JSON).build();
	}

	@GET
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Response truncate() throws JSONException {
		reqRepo.deleteAll();
		JSONObject jsonresponse = new JSONObject();
		jsonresponse.put("INFO", "Successful");

		return Response.status(200).entity(jsonresponse.toString())
				.type(MediaType.APPLICATION_JSON).build();
	}

}