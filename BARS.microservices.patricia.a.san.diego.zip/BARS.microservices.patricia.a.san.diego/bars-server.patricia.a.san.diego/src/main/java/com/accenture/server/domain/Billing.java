package com.accenture.server.domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Billing {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long billingId;

	private int billingCycle;
	private String billingMonth;
	private double amount;
	private Date startDate;
	private Date endDate;
	private String lastEdited;
	@ManyToOne
	@JoinColumn(name = "accountId")
	private Account account;

	public Billing() {

	}

	public Billing(int billingCycle, String billingMonth, double amount,
			Date startDate, Date endDate, String lastEdited, Account account) {

		this.billingCycle = billingCycle;
		this.billingMonth = billingMonth;
		this.amount = amount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.lastEdited = lastEdited;
		this.account = account;
	}

	public long getBillingId() {
		return billingId;
	}

	public void setBillingId(long billingId) {
		this.billingId = billingId;
	}

	public int getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(int billingCycle) {
		this.billingCycle = billingCycle;
	}

	public String getBillingMonth() {
		return billingMonth;
	}

	public void setBillingMonth(String billingMonth) {
		this.billingMonth = billingMonth;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getLastEdited() {
		return lastEdited;
	}

	public void setLastEdited(String lastEdited) {
		this.lastEdited = lastEdited;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

/*	@Override
	public String toString() {
		return "Billing [billingId=" + billingId + ", billingCycle="
				+ billingCycle + ", billingMonth=" + billingMonth + ", amount="
				+ amount + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", lastEdited=" + lastEdited + ", account=" + account + "]";
	}
*/
}
