package com.accenture.server.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long accountId;

	private String accountName;
	private Date dateCreated;
	private String isActive;
	private String lastEdited;
	@ManyToOne
	@JoinColumn(name = "customerId")
	private Customer customer;

	public Account() {

	}

	public Account(String accountName, Date dateCreated, String isActive,
			String lastEdited, Customer customer) {
		super();
		this.accountName = accountName;
		this.dateCreated = dateCreated;
		this.isActive = isActive;
		this.lastEdited = lastEdited;
		this.customer = customer;
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getLastEdited() {
		return lastEdited;
	}

	public void setLastEdited(String lastEdited) {
		this.lastEdited = lastEdited;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/*@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName="
				+ accountName + ", dateCreated=" + dateCreated + ", isActive="
				+ isActive + ", lastEdited=" + lastEdited + ", customer="
				+ customer + "]";
	}*/

}
