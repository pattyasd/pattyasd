package com.accenture.server.domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Request {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int requestId;

	private int billingCycle;
	private Date startDate;
	private Date endDate;

	public Request() {

	}

	public Request(int billingCycle, Date startDate, Date endDate) {
		this.billingCycle = billingCycle;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setBillingCycle(int billingCycle) {
		this.billingCycle = billingCycle;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public int getBillingCycle() {
		return billingCycle;
	}

	@Override
	public String toString() {
		return "Request [billingCycle=" + billingCycle + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}

}
