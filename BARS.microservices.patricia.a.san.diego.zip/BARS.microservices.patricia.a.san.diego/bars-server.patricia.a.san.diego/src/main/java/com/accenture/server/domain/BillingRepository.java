package com.accenture.server.domain;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BillingRepository extends JpaRepository<Billing, Long> {

	Billing findByBillingCycleAndStartDateAndEndDate (int billingCycle, Date startDate, Date endDate);
}
