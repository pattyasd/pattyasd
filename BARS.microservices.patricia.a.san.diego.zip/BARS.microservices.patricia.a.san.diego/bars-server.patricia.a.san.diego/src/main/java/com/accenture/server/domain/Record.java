package com.accenture.server.domain;

import java.sql.Date;

public class Record {
	/*private int billingCycle;
	private Date startDate;
	private Date endDate;
	private String firstName;
	private String lastName;
	private double amount;

	public Record() {

	}

	public Record(int billingCycle, Date startDate, Date endDate,
			String firstName, String lastName, double amount) {

		this.billingCycle = billingCycle;
		this.startDate = startDate;
		this.endDate = endDate;
		this.firstName = firstName;
		this.lastName = lastName;
		this.amount = amount;
	}

	public int getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(int billingCycle) {
		this.billingCycle = billingCycle;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Record [billingCycle=" + billingCycle + ", startDate="
				+ startDate + ", endDate=" + endDate + ", firstName="
				+ firstName + ", lastName=" + lastName + ", amount=" + amount
				+ "]";
	}*/

}
