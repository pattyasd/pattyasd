package com.accenture.server;

import java.text.SimpleDateFormat;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


import com.accenture.server.domain.Account;
import com.accenture.server.domain.AccountRepository;
import com.accenture.server.domain.Billing;
import com.accenture.server.domain.BillingRepository;
import com.accenture.server.domain.Customer;
import com.accenture.server.domain.CustomerRepository;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public CommandLineRunner loadData(CustomerRepository customer, AccountRepository account, BillingRepository billing) throws java.text.ParseException{
	SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
	java.util.Date date1 = format.parse("20130723 13:41:48");
	java.util.Date date2 = format.parse("20160101 00:00:00");
	java.util.Date date3 = format.parse("20160101 00:00:00");
	java.util.Date date4 = format.parse("20140209 16:11:25");

	SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
	java.util.Date ssdate1 = format1.parse("2013-01-15");
	java.sql.Date sdate1 = new java.sql.Date(ssdate1.getTime());

	java.util.Date eedate1 = format1.parse("2013-02-14");
	java.sql.Date edate1 = new java.sql.Date(eedate1.getTime());

	java.util.Date ssdate2 = format1.parse("2016-01-15");
	java.sql.Date sdate2 = new java.sql.Date(ssdate2.getTime());

	java.util.Date eedate2 = format1.parse("2016-02-14");
	java.sql.Date edate2 = new java.sql.Date(eedate2.getTime());

	java.util.Date ssdate3 = format1.parse("2016-02-01");
	java.sql.Date sdate3 = new java.sql.Date(ssdate3.getTime());

	java.util.Date eedate3 = format1.parse("2016-02-28");
	java.sql.Date edate3 = new java.sql.Date(eedate3.getTime());

	java.util.Date ssdate4 = format1.parse("2016-03-01");
	java.sql.Date sdate4 = new java.sql.Date(ssdate4.getTime());

	java.util.Date eedate4 = format1.parse("2016-03-31");
	java.sql.Date edate4 = new java.sql.Date(eedate4.getTime());

	java.util.Date ssdate5 = format1.parse("2013-02-15");
	java.sql.Date sdate5 = new java.sql.Date(ssdate5.getTime());

	java.util.Date eedate5 = format1.parse("2013-03-14");
	java.sql.Date edate5 = new java.sql.Date(eedate5.getTime());

	java.util.Date ssdate6 = format1.parse("2013-01-01");
	java.sql.Date sdate6 = new java.sql.Date(ssdate6.getTime());

	java.util.Date eedate6 = format1.parse("2013-01-31");
	java.sql.Date edate6 = new java.sql.Date(eedate6.getTime());

	Customer c1 = new Customer("Cristopher","Aspa","Florida, USA","Y", date1,"admin");
	Customer c2 = new Customer("Juan","dela Cruz","Philippines","Y", date2,"admin");
	Customer c3 = new Customer("Maria Clara","de los Santos","Philippines","Y", date3,"admin");
	Customer c4 = new Customer("Anthony","Stark","New York, USA","Y", date4,"admin");

	Account a1 = new Account("CRISTOPHER ASPA", date1, "Y", "admin", c1);
	Account a2 = new Account("JUAN DELA CRUZ", date2, "Y", "admin", c2);
	Account a3 = new Account("MARIA CLARA DE LOS SANTOS", date3, "Y", "admin", c3);
	Account a4 = new Account("ANTHONY STARK", date4, "Y", "admin", c4);

	return args ->{
	customer.save(c1);
	customer.save(c2);
	customer.save(c3);
	customer.save(c4);

	account.save(a1);
	account.save(a2);
	account.save(a3);
	account.save(a4);

	billing.save(new Billing(1,"January",7000, sdate1, edate1,"admin",a1));
	billing.save(new Billing(1,"January",15000, sdate2, edate2,"admin",a2));
	billing.save(new Billing(2,"February",10000, sdate3, edate3,"admin",a2));
	billing.save(new Billing(1,"March",25000, sdate4, edate4,"admin",a3));
	billing.save(new Billing(2,"February",10000, sdate5, edate5,"admin",a1));
	billing.save(new Billing(1,"January",8500, sdate6, edate6,"admin",a3));
	};
}
}
