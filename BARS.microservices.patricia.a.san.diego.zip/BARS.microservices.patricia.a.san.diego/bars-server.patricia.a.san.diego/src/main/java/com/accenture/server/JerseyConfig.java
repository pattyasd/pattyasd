package com.accenture.server;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import com.accenture.server.service.CheckService;
import com.accenture.server.service.ProcessService;


@Configuration
public class JerseyConfig extends ResourceConfig{

	public JerseyConfig() {
		register(ProcessService.class);
		register(CheckService.class);
	}
}
