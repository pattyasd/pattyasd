package com.accenture.client.file;

import java.io.File;
import java.util.List;

import com.accenture.client.domain.Request;
import com.accenture.client.exception.BarsException;

public interface IInputFile {

	public abstract List<Request> readFile() throws BarsException;

	public abstract void setFile(File file);

	public abstract File getFile();
}
