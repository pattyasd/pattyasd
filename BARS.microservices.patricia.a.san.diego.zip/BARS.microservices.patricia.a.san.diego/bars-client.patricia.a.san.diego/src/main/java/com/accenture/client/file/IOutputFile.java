package com.accenture.client.file;

import java.io.File;
import java.util.List;
import com.accenture.client.domain.Record;

public interface IOutputFile {

	public void writeFile(List<Record> record);
	public void setFile (File file);
	public File getFile();


}

