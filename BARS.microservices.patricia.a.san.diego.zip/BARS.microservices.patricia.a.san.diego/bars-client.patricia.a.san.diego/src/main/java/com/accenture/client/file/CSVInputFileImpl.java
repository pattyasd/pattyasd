package com.accenture.client.file;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.client.domain.Request;
import com.accenture.client.exception.BarsException;
import com.accenture.client.file.CSVInputFileImpl;
import com.accenture.client.file.CheckFileClass;

public class CSVInputFileImpl extends AbstractInputFile {
	private static final Logger LOGGER = Logger.getLogger(CSVInputFileImpl.class);
	private int row = 0;

	public List<Request> readFile() throws BarsException {
		List<Request> listCsv = new ArrayList<>();
		String[] csvArray;
		try {
			FileReader fileReaderCsv = new FileReader(super.getFile());
			BufferedReader bufferedReaderCsv = new BufferedReader(fileReaderCsv);
			String line = bufferedReaderCsv.readLine();

			if(line == null) {
				fileReaderCsv.close();
				bufferedReaderCsv.close();
				throw new BarsException(BarsException.NO_RECORDS_TO_READ);
			}

			while(line != null) {
				row++;
				csvArray = line.replaceAll("/", "").split(",");
				line = getInput(csvArray[0], csvArray[1], csvArray[2]);

				if (line.length() != 18) {
					fileReaderCsv.close();
					bufferedReaderCsv.close();
					throw new BarsException("Invalid input!");
				}
				CheckFileClass cfc = new CheckFileClass();
				listCsv.add(cfc.checkLine(line, row));

				line = bufferedReaderCsv.readLine();

			}
			fileReaderCsv.close();
			bufferedReaderCsv.close();
			return listCsv;
		} catch (FileNotFoundException e) {
			LOGGER.error("File not found on path! ", e);
		} catch (IOException e) {
			LOGGER.error("IO Exception! ", e);
		}
		return listCsv;
	}

	private String getInput(String bCycle, String sDate, String eDate) throws BarsException {
		String matcher = "[0-9]+$";
		String matcher2 = "[ ]+$";
		return getNBilling(bCycle, matcher, matcher2) + csvSDateLength(sDate) + csvEDateLength(eDate);
	}

	private String getNBilling(String bCycle, String matcher, String matcher2) {
		if(bCycle.length() == 1 && bCycle.matches(matcher)) {
			return "0" + bCycle;
		} else if(bCycle.length() == 1 && bCycle.matches(matcher2)) {
			return " " + bCycle;
		}
		return bCycle;
	}

	private String csvSDateLength(String sDate) throws BarsException {
		if(sDate.length() != 8) {
			throw new BarsException(BarsException.INVALID_START_DATE_FORMAT + row);
		}
		return sDate;
	}

	private String csvEDateLength(String eDate) throws BarsException {
		if(eDate.length() != 8) {
			throw new BarsException(BarsException.INVALID_END_DATE_FORMAT + row);
		}
		return eDate;
	}

}
