package com.accenture.client.file;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class BarsWriteXmlUtils implements BarsWriteXMLUtilsInterface {

	private static final Logger LOGGER = Logger
			.getLogger(BarsWriteXmlUtils.class);

	public Document createXMLDocument() {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder docBuilder;
		Document doc = null;
		try {
			docBuilder = docFactory.newDocumentBuilder();
			doc = docBuilder.newDocument();
		} catch (ParserConfigurationException e) {
			LOGGER.error("Parser Error! ", e);
		}

		return doc;
	}

	public Element createDocumentElement(Document doc, String elementName) {
		Element rootElement = doc.createElement(elementName);
		doc.appendChild(rootElement);
		return rootElement;
	}

	public Element createChildElement(Document doc, Element element,
			String elementName) {
		Element staff = doc.createElement(elementName);
		element.appendChild(staff);
		return staff;
	}

	public Element createElementAttribute(Document doc, Element element,
			String attName, String attValue) {
		Attr attr = doc.createAttribute(attName);
		attr.setValue(attValue);
		element.setAttributeNode(attr);

		return element;
	}

	public Element createElementTextNode(Document doc, Element element,
			String elementName, String nodeString) {
		Element el = doc.createElement(elementName);
		el.appendChild(doc.createTextNode(nodeString));
		element.appendChild(el);

		return element;
	}

	public void transformToXML(Document doc, String filePath) {
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException e) {
			LOGGER.error("Transformer Error! ", e);
		}
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filePath));

		// Output to console for testing

		try {
			if (transformer != null) {
				transformer.transform(source, result);
			}
		} catch (TransformerException e) {
			LOGGER.error("Transformer Error! ", e);
		}
	}

}