package com.accenture.client.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.Bean;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.accenture.client.domain.Record;
import com.accenture.client.exception.BarsException;
import com.accenture.client.service.ClientService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


@EnableCircuitBreaker
@Controller
public class BarsController {

	@Autowired
	private ClientService cs;

	private FileProcessor fileProcessor;
	private String errorText = "";

	@RequestMapping("/")
	public String goHome() {
		return "Home";
	}

	// http://localhost:8080/Home
	@RequestMapping("/process")
	public String processRequest(@RequestParam String file)
			throws JSONException, ParseException {
		fileProcessor = new FileProcessor();
		if (cs.readingList().equalsIgnoreCase("down")) {
			return "redirect:/serverdown";
		}
		try {
			JSONArray array = fileProcessor.execute(new File(file));
			Client client = new Client();
			WebResource wr = client
					.resource("http://localhost:9091/barsprocessing/insertdata");
			ClientResponse response = wr.type(MediaType.APPLICATION_JSON).post(
					ClientResponse.class, array.toString());
			@SuppressWarnings("unused")
			String restStr = response.getEntity(String.class);
			List<Record> record = fileProcessor.retrieveRecordfromDB();
			fileProcessor.writeOutput(record);
		} catch (java.text.ParseException | BarsException e) {
			errorText = e.getMessage();
			return "redirect:/errorpage";
		}

		return "redirect:/requestcomplete";
	}

	@Bean
	public RestTemplate rest(RestTemplateBuilder builder) {
		return builder.build();
	}

	@RequestMapping("/signout")
	public void signoutBars(HttpServletResponse response) {
		String url = "http://localhost:8080/";
		response.setHeader("Location", url);
		response.setStatus(302);
	}

	@RequestMapping("/errorpage")
	public String errorPage(Model model) {
		model.addAttribute("message", errorText);
		return "Error";
	}

	@RequestMapping("/serverdown")
	public String srvrdwn() {
		return "ServerDown";
	}

	@RequestMapping("/requestcomplete")
	public String successPage() {
		return "Success";
	}

}
