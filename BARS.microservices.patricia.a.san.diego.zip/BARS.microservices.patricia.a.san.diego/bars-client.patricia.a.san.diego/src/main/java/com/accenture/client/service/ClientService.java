package com.accenture.client.service;

import java.net.URI;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class ClientService {
	private final RestTemplate restTemplate;

	public ClientService(RestTemplate rest) {
		this.restTemplate = rest;
	}

	@HystrixCommand(fallbackMethod = "reliable")
	public String readingList() {
		URI uri = URI.create("http://localhost:9091/checker/check");

		return this.restTemplate.getForObject(uri, String.class);
	}

	public String reliable() {
		return "down";
	}

}
