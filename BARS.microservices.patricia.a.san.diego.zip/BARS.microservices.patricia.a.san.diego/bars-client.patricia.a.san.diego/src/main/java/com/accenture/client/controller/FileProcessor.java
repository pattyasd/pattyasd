package com.accenture.client.controller;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.accenture.client.domain.Record;
import com.accenture.client.domain.Request;
import com.accenture.client.exception.BarsException;
import com.accenture.client.factory.InputFileFactory;
import com.accenture.client.file.IInputFile;
import com.accenture.client.file.IOutputFile;
import com.accenture.client.file.XMLOutputFileImpl;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class FileProcessor {

	private IInputFile inputFile;
	private IOutputFile outputFile = new XMLOutputFileImpl();

	public JSONArray execute(File file) throws BarsException {
		InputFileFactory iff = InputFileFactory.getInstance();
		inputFile = iff.getInputFile(file);
		JSONArray array = new JSONArray();
		if (inputFile != null) {
			inputFile.setFile(file);
			List<Request> request = inputFile.readFile();
			for (Request req : request) {
				JSONObject json = new JSONObject();
				try {
					json.put("billing", req.getBillingCycle());
					json.put("startDate", req.getStartDate());
					json.put("endDate", req.getEndDate());
					array.put(json);
				} catch (JSONException e) {
					throw new BarsException("JSON Parsing Error");
				}
			}
			return array;
		} else {
			throw new BarsException(BarsException.NO_SUPPORTED_FILE);
		}
	}

	public List<Record> retrieveRecordfromDB() throws BarsException,
			JSONException, ParseException {
		// initializing recordDAO
		Client client = new Client();
		WebResource wr = client
				.resource("http://localhost:9091/barsprocessing/viewbilling");
		ClientResponse response = wr.type(MediaType.APPLICATION_JSON).get(
				ClientResponse.class);
		String restStr = response.getEntity(String.class);
		if (restStr.length() == 0) {
			throw new BarsException(BarsException.NO_RECORDS_TO_WRITE);
		}
		JSONArray array = new JSONArray(restStr);
		List<Record> list = new ArrayList<>();
		for (int i = 0; i < array.length(); i++) {
			JSONObject json = array.getJSONObject(i);
			Record record = new Record();
			record.setBillingCycle(json.getInt("billingCycle"));
			record.setCustomerFirstName(json.getString("firstName"));
			record.setCustomerLastName(json.getString("lastName"));
			record.setAmount(json.getDouble("amount"));
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date = sdf1.parse(json.getString("startDate"));
			java.sql.Date sDate = new java.sql.Date(date.getTime());
			record.setStartDate(sDate);
			java.util.Date date1 = sdf1.parse(json.getString("endDate"));
			java.sql.Date eDate = new java.sql.Date(date1.getTime());
			record.setEndDate(eDate);
			list.add(record);
		}
		return list;
	}

	public void writeOutput(List<Record> record) {
		outputFile.writeFile(record);
	}

}
