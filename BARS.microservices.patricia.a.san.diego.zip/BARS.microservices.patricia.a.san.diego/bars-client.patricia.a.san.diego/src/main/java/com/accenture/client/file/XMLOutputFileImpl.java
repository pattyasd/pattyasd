package com.accenture.client.file;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.log4j.Logger;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.accenture.client.domain.Record;
import com.accenture.client.file.BarsWriteXMLUtilsInterface;
import com.accenture.client.file.BarsWriteXmlUtils;
import com.accenture.client.file.XMLOutputFileImpl;

public class XMLOutputFileImpl extends AbstractOutputFile {

	private static final Logger LOGGER = Logger.getLogger(XMLOutputFileImpl.class);

	public void writeFile(List<Record> records) {

		BarsWriteXMLUtilsInterface x = new BarsWriteXmlUtils();

		Document doc = x.createXMLDocument();

		Element rootElement = x.createDocumentElement(doc, "BARS");

		for(int i = 0; i < records.size(); i++) {
			Element request = x.createChildElement(doc, rootElement, "request");
			x.createElementTextNode(doc, request, "billing-cycle", Integer.toString(records.get(i).getBillingCycle()));
			x.createElementTextNode(doc, request, "start-date", records.get(i).getStartDate().toString());
			x.createElementTextNode(doc, request, "end-date", records.get(i).getEndDate().toString());
			x.createElementTextNode(doc, request, "first-name", records.get(i).getCustomerFirstName());
			x.createElementTextNode(doc, request, "last-name", records.get(i).getCustomerLastName());
			x.createElementTextNode(doc, request, "amount", Double.toString(records.get(i).getAmount()));
		}

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String time = dtf.format(LocalDateTime.now());

        new File("C:/BARS/Report").mkdirs();

        String filename = "C:/BARS/Report/BARS_Report-" + time + ".xml";
        Schema schema = null;
    	try {
    	  String language = XMLConstants.W3C_XML_SCHEMA_NS_URI;
    	  SchemaFactory factory = SchemaFactory.newInstance(language);
    	  schema = factory.newSchema(ResourceUtils.getFile(this.getClass().getResource("/bars_output.xsd")));
    	  Validator validator = schema.newValidator();
    	  validator.validate(new DOMSource(doc));
    	  x.transformToXML(doc, filename);
    	  super.setFile(new File(filename));
    	} catch (Exception e) {
    		LOGGER.error("Parser error! ", e);
    	}

	}

}
