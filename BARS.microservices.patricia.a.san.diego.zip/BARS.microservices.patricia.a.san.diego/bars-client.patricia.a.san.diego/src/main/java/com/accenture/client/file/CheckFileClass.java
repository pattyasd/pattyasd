package com.accenture.client.file;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

import java.sql.Date;

import org.apache.log4j.Logger;

import com.accenture.client.domain.Request;
import com.accenture.client.exception.BarsException;

public class CheckFileClass {
	private static final Logger LOGGER = Logger.getLogger(CheckFileClass.class);

	public Request checkLine(String line, int row) throws BarsException {
		try {
			Request request = new Request();
			request.setBillingCycle(checkBillingCycle(
					Integer.parseInt(line.substring(0, 2)), row));

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
					"MMdduuuu").withResolverStyle(ResolverStyle.STRICT);

			request.setStartDate(checkStartDate(formatter,
					line.substring(2, 10), row));
			request.setEndDate(checkEndDate(formatter, line.substring(10, 18),
					row));
			return request;
		} catch (NumberFormatException e) {
			throw new BarsException(BarsException.BILLING_CYCLE_NOT_ON_RANGE
					+ row);
		}
	}

	private int checkBillingCycle(int billing, int row) throws BarsException {
		if (billing > 0 && billing < 13) {
			return billing;
		} else {
			throw new BarsException(BarsException.BILLING_CYCLE_NOT_ON_RANGE
					+ row);
		}
	}

	private Date checkStartDate(DateTimeFormatter formatter, String date,
			int row) throws BarsException {
		try {
			return Date.valueOf(LocalDate.parse(date, formatter));
		} catch (DateTimeParseException e) {
			LOGGER.error("Date Time parse error! ", e);
			throw new BarsException(BarsException.INVALID_START_DATE_FORMAT
					+ row);
		}
	}

	private Date checkEndDate(DateTimeFormatter formatter, String date, int row)
			throws BarsException {
		try {
			return Date.valueOf(LocalDate.parse(date, formatter));
		} catch (DateTimeParseException e) {
			LOGGER.error("Date Time parse error! ", e);
			throw new BarsException(BarsException.INVALID_END_DATE_FORMAT + row);
		}
	}
}
