package com.accenture.client.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;



import org.apache.log4j.Logger;

import com.accenture.client.controller.BarsController;
import com.accenture.client.domain.Request;
import com.accenture.client.exception.BarsException;

public class TextInputFileImpl extends AbstractInputFile {
	Logger logger = Logger.getLogger(BarsController.class);

	public List<Request> readFile() throws BarsException {
		List<Request> list = new ArrayList<Request>();
		try {
			FileReader fileReader = new FileReader(super.getFile());

			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line = bufferedReader.readLine();
			int row = 0;

			if (line == null) {
				throw new BarsException(BarsException.NO_RECORDS_TO_READ);
			}

			while (line != null) {
				row++;

				if (line.length() != 18) {
					System.out.println("Length not 18 at row " + row);
					break;
				}

				if (line.matches("[0-9]+$")) {
					Request request = new Request();
					int bill = Integer.parseInt(line.substring(0, 2));
					if (bill > 0 && bill < 13) {
						request.setBillingCycle(bill);
					} else {
						throw new BarsException(
								BarsException.BILLING_CYCLE_NOT_ON_RANGE + row);
					}

					DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
							"MMdduuuu").withResolverStyle(ResolverStyle.STRICT);

					try {
						request.setStartDate(Date.valueOf(LocalDate.parse(
								line.substring(2, 10), formatter)));

					} catch (DateTimeParseException e) {
						throw new BarsException(
								BarsException.INVALID_START_DATE_FORMAT + row);
					}

					try {
						request.setEndDate(Date.valueOf(LocalDate.parse(
								line.substring(10, 18), formatter)));
					} catch (DateTimeParseException e) {
						throw new BarsException(
								BarsException.INVALID_END_DATE_FORMAT + row);
					}

					list.add(request);

				} else {
					throw new BarsException("Invalid request format at row "
							+ row);
				}

				line = bufferedReader.readLine();

			}
			return list;
		} catch (FileNotFoundException e) {
			throw new BarsException(BarsException.PATH_DOES_NOT_EXIST);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void setFile(File file) {
		super.setFile(file);
	}

	public File getFile() {
		return super.getFile();
	}

}
