package com.accenture.client.file;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class BarsReadXMLUtils implements BarsReadXMLUtilsInterface{

	public NodeList retrieveXMLNodeList(String filePath, String tagName) {
		File fXmlFile = new File(filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		Document doc = null;
		try {
			doc = dBuilder.parse(fXmlFile);
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		doc.getDocumentElement().normalize();

		//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		NodeList nList = doc.getElementsByTagName(tagName);


		return nList;
	}

	public List<Element> retrieveNodeElement(NodeList nList) {
		// TODO Auto-generated method stub
		List<Element> elementList = new ArrayList<Element>();
		for (int temp = 0; temp < nList.getLength(); temp++) {

			   Node nNode = nList.item(temp);

			   if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			      Element eElement = (Element) nNode;
			      elementList.add(eElement);

			   }
		}

		return elementList;
	}

	public String getElementNodeValue(Element element,String elementName) {
		// TODO Auto-generated method stub
		return element.getElementsByTagName(elementName).item(0).getChildNodes().item(0).getNodeValue();
	}



}
