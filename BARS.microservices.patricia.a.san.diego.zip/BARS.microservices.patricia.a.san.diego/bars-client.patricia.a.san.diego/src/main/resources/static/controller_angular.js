var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {
	$http.get("http://localhost:9091/barsprocessing/viewbilling").then(
			function(response) {
				$scope.myData = response.data;
			}
	)
});