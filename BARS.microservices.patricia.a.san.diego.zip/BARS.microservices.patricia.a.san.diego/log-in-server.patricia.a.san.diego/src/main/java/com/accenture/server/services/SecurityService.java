package com.accenture.server.services;

import java.util.Base64;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.server.domain.User;
import com.accenture.server.domain.UserRepository;

@Path("/securityservice")
public class SecurityService {
	@Autowired
	private UserRepository repo;

	List<User> info = null;

	// http://localhost:8082/securityservice/login
	@GET
	@Path("/login")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getOrderById(@PathParam("orderId") int orderID,
			@HeaderParam("Authorization") String authString)
			throws JSONException {

		JSONObject json = new JSONObject();

		if (isUserAuthenticated(authString)) {

			if (isAdminUser(authString)) {
				json.put("INFO", "Admin User");
				return Response.status(200).entity(json.toString())
						.type(MediaType.APPLICATION_JSON).build();
			} else {
				json.put("INFO", "Authorized");
				return Response.status(200).entity(json.toString())
						.type(MediaType.APPLICATION_JSON).build();
			}

		} else {
			json.put("ERROR", "Unauthorized");
			return Response.status(403).entity(json.toString())
					.type(MediaType.APPLICATION_JSON).build();
		}

	}

	private boolean isUserAuthenticated(String authString) {

		// authString = BASIC asjfalsdlf
		String[] authParts = authString.split("\\s+");
		String authInfo = authParts[1];// eto ung credentials dun sa
										// "BASIC kalhfakshfk"
		byte[] bytes = Base64.getDecoder().decode(authInfo);

		String decodedAuth = new String(bytes);

		// sample decodedAuth = sally:1234
		String[] credentials = decodedAuth.split(":");

		if (repo.findByUsernameAndPassword(credentials[0], credentials[1]) != null) {

			return true;

		} else {
			return false;
		}

	}

	private boolean isAdminUser(String authString) {
		String[] authParts = authString.split("\\s+");
		String authInfo = authParts[1];//

		byte[] bytes = Base64.getDecoder().decode(authInfo);

		String decodedAuth = new String(bytes);

		// sample decodedAuth = sally:1234
		String[] credentials = decodedAuth.split(":");

		if (repo.findByRole(true, credentials[0], credentials[1]) != null) {
			return true;

		} else {
			return false;
		}

	}

}
