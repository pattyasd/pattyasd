package com.accenture.client.controller;

import java.util.Base64;

import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Service
public class Login {

	@HystrixCommand(fallbackMethod = "reliable")
	public ModelAndView userValidation(@RequestParam String username,
			@RequestParam String password) {

		ModelAndView mv = new ModelAndView();

		String user = username;
		String pass = password;

		String authString = user + ":" + pass;
		String authStr = Base64.getEncoder().encodeToString(
				authString.getBytes());

		Client restClient = new Client();
		WebResource wr = restClient
				.resource("http://localhost:8082/securityservice/login");
		ClientResponse resp = wr.type(MediaType.APPLICATION_JSON)
				.header("Authorization", "Basic " + authStr)
				.get(ClientResponse.class);

		String output = resp.getEntity(String.class);
		System.out.println(output);
		if (output.contains("Admin")) {
			mv.setViewName("ViewAll");
		} else if (output.contains("Authorized")) {
			mv.setViewName("HomeUser");
		} else {
			mv.setViewName("InvalidUser");
		}

		return mv;
	}

	public ModelAndView reliable(
			@RequestParam(value = "username") String username,
			@RequestParam(value = "password") String password) {

		ModelAndView mv = new ModelAndView();

		mv.setViewName("Hystrix");

		return mv;

	}
}