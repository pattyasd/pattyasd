package com.accenture.client.controller;

public class View {

}
