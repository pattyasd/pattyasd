var app = angular.module('directiveApp',[]);


app.controller("DirectiveCtrl", function ($scope){

	$scope.showGreeting = function () {
		alert("Hello");
	}
	
	
	$scope.logChore = function (chore){
		alert(chore + " is done!");
	
	}

})

app.directive( "enter", function() {

	return function(scope, element, attrs) {
		element.bind("mouseenter", function () {
			console.log("wow");
			scope.$apply(attrs.enter);

		});
	}

})

app.directive( "leave", function() {

	return function(scope, element) {
		element.bind("mouseleave", function () {
			console.log("woah");
		});
	}

})

app.directive( "superhero", function() {

	return {
	
		link: function (scope, element){
			element.addClass("backgroundRed");
			console.log("super");
		}
	
	}

})


app.directive( "kid", function() {

	return {
		restrict : "E",
		scope: {
			done: "&"
		
		},
		template: '<br><input type="text" ng-model="chore">' +
					'{{chore}} ' +
					'<input type="button" value="I\'m done" ng-click = "done({chore:chore})"></input>'
				
	
	}


})


