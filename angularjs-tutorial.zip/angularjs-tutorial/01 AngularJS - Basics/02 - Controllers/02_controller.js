var myApp = angular.module('myApp',[]);

myApp.controller('myCtrl', ['$scope', function($scope) {
  $scope.hello = 'Hahaha!';
  
  
  $scope.animes = [
		{title: 'Rurouni Kenshin', genre: 'Action'},
		{title: 'Kimi ni Todoke', genre: 'Romantic Comedy'},
		{title: 'Anohana', genre: 'Drama'},
		{title: 'Kuroko no Basuke', genre: 'Sport'}
	];
    
  
}]);