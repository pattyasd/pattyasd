var myApp = angular.module('myApp',[]);

myApp.controller('myCtrl', ['$scope', function($scope) {
 
 
	$scope.categories = [
		{id: 0, name: 'Anime'},
		{id: 1, name: 'Disney'},
		{id: 2, name: 'Pixar'}
	
	];
 
   $scope.shows = [
		{title: 'Rurouni Kenshin', category: 'Anime'},
		{title: 'Kimi ni Todoke', category: 'Anime'},
		{title: 'Anohana', category: 'Anime'},
		{title: 'Kuroko no Basuke', category: 'Anime'},
		
		{title: 'Little Mermaid', category: 'Disney'},
		{title: 'Mulan', category: 'Disney'},
		{title: 'Sleeping Beauty', category: 'Disney'},
		{title: 'Snow White', category: 'Disney'},
		
		{title: 'Toy Story', category: 'Pixar'},
		{title: 'Finding Nemo', category: 'Pixar'},
		{title: 'The Incredibles', category: 'Pixar'},
		{title: 'Wall-E', category: 'Pixar'}
	];
  

	$scope.currentCategory = null;
	
	//private function
	function setCurrentCategory(category){
		
		$scope.currentCategory = category;	
	
	}
	
	function isCurrentCategory(category){
	
		return $scope.currentCategory!==null && category.name === $scope.currentCategory.name;
	}
	
	// makes function available to view by attaching to scope
	$scope.setCurrentCategory = setCurrentCategory; 
	$scope.isCurrentCategory = isCurrentCategory;
	
	/*****************
	*  DEFAULT VIEW   *
	******************/
	
	
	 resetView = function(){
		$scope.isCreateView = false;
		$scope.isEditView = false;
	}
	

	
	/*****************
	*  CREATE VIEW   *
	******************/
	
	
	
	function showCreateView(){
		$scope.isCreateView = true;
		$scope.isEditView = false;
		
		resetCreateForm();
	}
	
	function cancelCreateView(){
		$scope.isCreateView = false;
	
	}
	
	//show create view if currentCategory is not null and isEditView is false
	function shouldShowCreateView(){
		return $scope.currentCategory && !$scope.isEditView
	}
	
	/***************
	*  EDIT VIEW   *
	****************/
	
	function showEditView(){
		$scope.isCreateView = false;
		$scope.isEditView = true;
	
	}
	

	function cancelEditView(){
		$scope.isEditView = false;
	}
	
	
	//show edit view if isEditing flag is true and isCreateView flag is false
	function shouldShowEditView(){
		return $scope.isEditView;
	}
	
	$scope.resetView = resetView;
	$scope.showCreateView = showCreateView; 
	$scope.showEditView = showEditView; 
	$scope.cancelCreateView = cancelCreateView; 
	$scope.cancelEditView = cancelEditView; 
	$scope.shouldShowCreateView = shouldShowCreateView; 
	$scope.shouldShowEditView = shouldShowEditView; 
	
	
	
	
	
	
	/*********
	* CRUD   *
	*********/
	
	
	/*********
	* CREATE *
	*********/
	
	function createShow(show){
		show.id = $scope.shows.length; //for demo purposes set length as id
		$scope.shows.push(show);
		
		resetCreateForm();
	
	}
	
	function resetCreateForm(){
		$scope.newShow = {
			title: '',
			category: $scope.currentCategory
		};
	
	}
	
	$scope.createShow = createShow;
	
	/*********
	* UPDATE *
	*********/
	
	setEditedShow = function(show){
		$scope.existingShow = show;
		//creates a copy of the show object
		$scope.editedShow = angular.copy(show);
	}
	
	editShow = function(){
		// get index of the selected show
		var index = $scope.shows.indexOf($scope.existingShow); 
		//update the item in the array with the update
		$scope.shows[index] = $scope.editedShow;
		//clear the form
		resetEditForm();
		//close the edit view
		cancelEditView();
	
	}
		
	//clears the form
	function resetEditForm(){
		$scope.editedShow = {
			title: '',
			category: $scope.currentCategory
		};
	
	}
	
	$scope.setEditedShow = setEditedShow;
	$scope.editShow = editShow;
	
	
	
	/***********
	*  DELETE  *
	************/
	
	deleteShow = function(show){
	
		var index = $scope.shows.indexOf(show); 
		$scope.shows.splice(index, 1);
	}
	
	$scope.deleteShow = deleteShow;
  
}]);