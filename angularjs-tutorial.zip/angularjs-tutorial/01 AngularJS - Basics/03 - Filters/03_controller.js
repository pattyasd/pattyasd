var myApp = angular.module('myApp',[]);

myApp.controller('myCtrl', ['$scope', function($scope) {
 
 
	$scope.categories = [
		{id: 0, name: 'Anime'},
		{id: 1, name: 'Disney'},
		{id: 2, name: 'Pixar'}
	
	];
 
   $scope.shows = [
		{title: 'Rurouni Kenshin', category: 'Anime'},
		{title: 'Kimi ni Todoke', category: 'Anime'},
		{title: 'Anohana', category: 'Anime'},
		{title: 'Kuroko no Basuke', category: 'Anime'},
		
		{title: 'Little Mermaid', category: 'Disney'},
		{title: 'Mulan', category: 'Disney'},
		{title: 'Sleeping Beauty', category: 'Disney'},
		{title: 'Snow White', category: 'Disney'},
		
		{title: 'Toy Story', category: 'Pixar'},
		{title: 'Finding Nemo', category: 'Pixar'},
		{title: 'The Incredibles', category: 'Pixar'},
		{title: 'Wall-E', category: 'Pixar'}
	];
  

	$scope.currentCategory = null;
	
	//private function
	function setCurrentCategory(category){
		
		$scope.currentCategory = category;	
	
	}
	
	function isCurrentCategory(category){
	
		return $scope.currentCategory!==null && category.name === $scope.currentCategory.name;
	}
	
	// makes function available to view by attaching to scope
	$scope.setCurrentCategory = setCurrentCategory; 
	$scope.isCurrentCategory = isCurrentCategory;
  
}]);