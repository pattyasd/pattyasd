package com.accenture.client.controller;

import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Controller
public class UserInsertController {

	@RequestMapping("/insertUsers")
	public String redirectToInput() {
		return "insertNewUser";
	}

	@RequestMapping("/insertRequest")
	public String registerUser(@RequestParam String firstname,
			@RequestParam String lastname, @RequestParam String username,
			@RequestParam String password, @RequestParam String admin)
			throws JSONException {
		boolean check = false;

		if (admin.equals("Yes")) {
			check = true;
		} else {
			check = false;
		}

		JSONObject json = new JSONObject();
		json.put("firstname", firstname);
		json.put("lastname", lastname);
		json.put("username", username);
		json.put("password", password);
		json.put("admin", admin);

		Client client = new Client();

		WebResource wr = client.resource("http://8085/register/registeruser");
		ClientResponse response = wr.type(MediaType.APPLICATION_JSON).post(
				ClientResponse.class, json.toString());
		@SuppressWarnings("unused")
		String restStr = response.getEntity(String.class);

		return "redirect:/homeadmin";
	}

}
