package com.accenture.client.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/homeadmin")
	public String redirectAdmin() {
		return "admin";
	}

	@RequestMapping("/homeuser")
	public String redirectUser() {
		return "user";
	}

	@RequestMapping("/invalidacc")
	public String redirectWrong() {
		return "wrongdata";
	}
}
