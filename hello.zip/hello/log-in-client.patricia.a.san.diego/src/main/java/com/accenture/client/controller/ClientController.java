package com.accenture.client.controller;

import java.util.Base64;

import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Controller
public class ClientController {
	@RequestMapping("/login")
	public String loginMethod(@RequestParam String username,
			@RequestParam String password) {
		String url = "http://localhost:8082/validation/validate";
		String user = username;
		String pass = password;

		String authString = user + ":" + pass;
		String authStr = Base64.getEncoder().encodeToString(
				authString.getBytes());

		Client restClient = new Client();
		WebResource wr = restClient.resource(url);
		ClientResponse resp = wr.type(MediaType.APPLICATION_JSON)
				.header("Authorization", "Basic" + authStr)
				.get(ClientResponse.class);

		String output = resp.getEntity(String.class);
		if (output.contains("Admin User")) {
			return "redirect:/homeadmin";
		} else if (output.contains("Authorized User")) {
			return "redirect:/homeuser";
		} else {
			return "redirect:/invalidacc";
		}
	}
}
