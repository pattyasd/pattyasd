package com.accenture.server.domain;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "user", path = "user")
public interface UserRepository extends JpaRepository<User, Long> {

	@Query("Select u from User u where u.username = ?1 and u.password = ?2")
	User findUserPass(String username, String password);

	/*@Query("select u.username, u.admin from User u")
	List<User> findAllQuery();

	@Query("select u from User u where u.username = ?1")
	User findIfExisting(String username);

	@Query("select u from User u where u.id = ?1")
	User findDataById(Long id);*/

	@Transactional
	@Modifying
	@Query("Update User u set u.username = ?2, u.password = ?3, u.firstname = ?4, u.lastname = ?5 where u.id = ?1")
	void updateQuery(Long userid, String username, String password,
			String firstname, String lastname);
}
