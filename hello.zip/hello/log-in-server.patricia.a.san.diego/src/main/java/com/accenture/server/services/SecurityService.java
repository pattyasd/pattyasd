package com.accenture.server.services;

import java.util.Base64;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.server.domain.User;
import com.accenture.server.domain.UserRepository;

@Path("/validation")
public class SecurityService {
	@Autowired
	UserRepository userrepo;

	User useraccount = null;

	// http://localhost:8082/validation/validate
	@GET
	@Path("/validate")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getOrderById(@HeaderParam("Authorization") String authString)
			throws JSONException {

		JSONObject json = new JSONObject();

		if (isUserAuthenticated(authString)) {

			json.put("INFO", "Authorized User");
			return Response.status(200).entity(json.toString())
					.type(MediaType.APPLICATION_JSON).build();
		} else {
			return Response.status(401).entity(json.toString())
					.type(MediaType.APPLICATION_JSON).build();
		}
	}

	private boolean isUserAuthenticated(String authString) {

		// sample authString = BASIC asdfghjkl

		String[] authParts = authString.split("\\s+");
		String authInfo = authParts[1];
		byte[] bytes = Base64.getDecoder().decode(authInfo);
		String decodedAuth = new String(bytes);

		// sample decodedAuth = sally:1234
		String[] credentials = decodedAuth.split(":");

		if (userrepo.findUserPass(credentials[0], credentials[1]) != null) {
			return true;
		} else {
			return false;
		}

	}
}
