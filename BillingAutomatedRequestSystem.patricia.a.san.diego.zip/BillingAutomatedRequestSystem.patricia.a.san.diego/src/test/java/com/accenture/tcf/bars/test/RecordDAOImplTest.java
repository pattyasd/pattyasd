package com.accenture.tcf.bars.test;

public class RecordDAOImplTest {

}
