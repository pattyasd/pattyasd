package com.accenture.tcf.bars.file;

public class BarsWriteXMLUtilsInterface {
	
}
