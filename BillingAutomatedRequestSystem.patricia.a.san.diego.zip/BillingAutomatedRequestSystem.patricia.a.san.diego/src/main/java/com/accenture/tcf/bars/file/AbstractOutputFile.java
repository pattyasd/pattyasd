package com.accenture.tcf.bars.file;

import java.io.File;
import java.util.logging.Logger;

public abstract class AbstractOutputFile implements IOutputFile{
	private File file;


	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	//protected static final Logger logger;
}
