package com.accenture.tcf.bars.factory;

import java.io.File;

import com.accenture.tcf.bars.file.CSVInputFileImpl;
import com.accenture.tcf.bars.file.IInputFile;
import com.accenture.tcf.bars.file.TextInputFileImpl;

public class InputFileFactory {

	private static InputFileFactory iff;

	private InputFileFactory(){

	}

	public static InputFileFactory getInstance(){
		if(iff == null) {
			iff = new InputFileFactory();
		}
		return iff;
	}

	public IInputFile getInputFile(File file){
		if(file.getName().toLowerCase().endsWith("txt")) {
			return new TextInputFileImpl();
		}
		else if(file.getName().toLowerCase().endsWith("csv")) {
			return new CSVInputFileImpl();
		}
		return null;
	}

}
