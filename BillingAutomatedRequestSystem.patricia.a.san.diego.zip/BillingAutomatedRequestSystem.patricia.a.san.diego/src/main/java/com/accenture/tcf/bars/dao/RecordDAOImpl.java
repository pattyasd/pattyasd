package com.accenture.tcf.bars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.accenture.tcf.bars.domain.Record;

public class RecordDAOImpl implements IRecordDAO {
	private Connection conn;

	public RecordDAOImpl(Connection conn) {
		this.conn = conn;
	}

	public List<Record> retrieveRecords() {
		// TODO Auto-generated method stub
		List<Record> list = new ArrayList<Record>();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement("Select b.billing_cycle, "
							+ "b.start_date, "
							+ "b.end_date, "
							+ "c.first_name, "
							+ "c.last_name, "
							+ "b.amount "
							+ "from billing b "
							+ "Inner Join request r On b.start_date = r.start_date And b.end_date = b.end_date "
							+ "Inner Join account a On a.account_id = b.account_id "
							+ "Inner Join customer c On c.customer_id = a.customer_id;");
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Record rec = new Record();
				rec.setBillingCycle(rs.getInt(1));
				rec.setStartDate(rs.getDate(2));
				rec.setEndDate(rs.getDate(3));
				rec.setCustomerFirstName(rs.getString(4));
				rec.setCustomerLastName(rs.getString(5));
				rec.setAmount(rs.getDouble(6));
				list.add(rec);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
