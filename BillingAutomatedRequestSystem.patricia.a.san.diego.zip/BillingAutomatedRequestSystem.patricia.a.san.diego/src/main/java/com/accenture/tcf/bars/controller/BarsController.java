package com.accenture.tcf.bars.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.tcf.bars.domain.Record;
import com.accenture.tcf.bars.domain.Request;
import com.accenture.tcf.bars.exception.BarsException;

@Controller
public class BarsController {
	private FileProcessor fileProcessor;
	private Logger logger;

	@SuppressWarnings("unused")
	@RequestMapping("/process.htm")
	public ModelAndView processRequest(HttpServletRequest request,
			HttpServletResponse response) throws BarsException {
		fileProcessor = new FileProcessor();
		ModelAndView mv = new ModelAndView();
		try {
			fileProcessor.execute(new File(request.getParameter("file")));
			List<Record> req = fileProcessor.retrieveRecordfromDB();
			fileProcessor.writeOutput(req);
			request.setAttribute("ArrayListValues", req);
			mv.setViewName("Success.jsp");
		} catch (BarsException e) {
			String setName = "message";

			if(e.getMessage().contains("ERROR: Invalid Start Date format at row")) {
				request.setAttribute(setName, e.getMessage());
				mv.setViewName("error_invalid_start_date.jsp");

			} else if(e.getMessage().contains("ERROR: Invalid End Date format at row")) {
				request.setAttribute(setName, e.getMessage());
				mv.setViewName("error_invalid_end_date.jsp");

			} else if(e.getMessage().contains("ERROR: Billing Cycle not on range at row")) {
				request.setAttribute(setName, e.getMessage());
				mv.setViewName("error_billing_cycle.jsp");

			} else if(e.getMessage().contains("Please put an existing request file path")) {
				mv.setViewName("");

			} else if(e.getMessage().contains("No supported request file found in the file path")) {
				mv.setViewName("error_format.html");

			} else if(e.getMessage().contains("No request(s) to read from the input file")) {
				mv.setViewName("error_no_request.html");

			} else if(e.getMessage().contains("No record(s) to write from the input file")) {
				mv.setViewName("error_no_request.html");

			} else if(e.getMessage().contains("No record(s) to write to the output file")) {
				mv.setViewName("error_no_records.html");
			}
		}

		return mv;

	}
}
