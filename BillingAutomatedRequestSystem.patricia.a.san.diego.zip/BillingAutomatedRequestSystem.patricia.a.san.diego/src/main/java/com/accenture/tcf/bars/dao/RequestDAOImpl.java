package com.accenture.tcf.bars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.accenture.tcf.bars.domain.Request;

public class RequestDAOImpl implements IRequestDAO {

	private Connection conn;

	public RequestDAOImpl(Connection conn) {
		this.conn = conn;
	}

	public void insertRequest(Request request) {
		try {
			PreparedStatement pstate = conn
					.prepareStatement("INSERT INTO request (billing_cycle, start_date, end_date) VALUES (?, ?, ?)");
			pstate.setInt(1, request.getBillingCycle());
			pstate.setDate(2, request.getStartDate());
			pstate.setDate(3, request.getEndDate());
			pstate.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteRequest() {
		try {

			Statement state = conn.createStatement();

			state.executeUpdate("TRUNCATE TABLE request;");
			conn.close();
			state.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
