package com.accenture.tcf.bars.datasource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLDatasource {

	private static Connection con;

	public MySQLDatasource() {

	}

	public static Connection getConnection() {
		String url = "jdbc:mysql://localhost/bars_db";
		String username = "root";
		String password = "abcd1234";

		try {
			// loading the driver
			Class.forName("com.mysql.jdbc.Driver");
			// getting the connection
			con = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return con;
	}

}
