package com.accenture.tcf.bars.file;

import java.io.File;
import java.util.List;

import com.accenture.tcf.bars.domain.Request;
import com.accenture.tcf.bars.exception.BarsException;

public interface IInputFile {

	public abstract List<Request> readFile() throws BarsException;

	public abstract void setFile(File file);

	public abstract File getFile();
}
