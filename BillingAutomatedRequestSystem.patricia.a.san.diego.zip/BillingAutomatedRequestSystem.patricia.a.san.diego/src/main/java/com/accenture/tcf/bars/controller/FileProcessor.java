package com.accenture.tcf.bars.controller;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.accenture.tcf.bars.dao.IRecordDAO;
import com.accenture.tcf.bars.dao.IRequestDAO;
import com.accenture.tcf.bars.dao.RecordDAOImpl;
import com.accenture.tcf.bars.dao.RequestDAOImpl;
import com.accenture.tcf.bars.datasource.MySQLDatasource;
import com.accenture.tcf.bars.domain.Record;
import com.accenture.tcf.bars.domain.Request;
import com.accenture.tcf.bars.exception.BarsException;
import com.accenture.tcf.bars.factory.InputFileFactory;
import com.accenture.tcf.bars.file.IInputFile;
import com.accenture.tcf.bars.file.IOutputFile;
import com.accenture.tcf.bars.file.XMLOutputFileImpl;

public class FileProcessor {

	private File file;
	private Connection conn = MySQLDatasource.getConnection();
	private IInputFile inputFile;
	private IOutputFile outputFile = new XMLOutputFileImpl();
	private IRequestDAO requestDAO;
	private IRecordDAO recordDAO;

	public void execute(File file) throws BarsException {
		InputFileFactory iff = InputFileFactory.getInstance();
		inputFile = iff.getInputFile(file);

		if (inputFile != null) {
			inputFile.setFile(file);

			List<Request> request = inputFile.readFile();

			requestDAO = new RequestDAOImpl(conn);
			for (int i = 0; i < request.size(); i++) {
				Request req = request.get(i);
				requestDAO.insertRequest(req);
			}
			outputFile.setFile(file);
		} else {
			throw new BarsException(BarsException.NO_SUPPORTED_FILE);
		}
	}

	public List<Record> retrieveRecordfromDB() throws BarsException {
	recordDAO = new RecordDAOImpl(conn);
		List<Record> list = recordDAO.retrieveRecords();
		if (list.size() == 0) {
			throw new BarsException(BarsException.NO_RECORDS_TO_WRITE);
		}
		/*
		 * list.stream().forEach(e -> { System.out.println(e); });
		 */
		return list;
	}

	public void writeOutput(List<Record> record) {
		outputFile.writeFile(record);
		requestDAO.deleteRequest();
	}

}
