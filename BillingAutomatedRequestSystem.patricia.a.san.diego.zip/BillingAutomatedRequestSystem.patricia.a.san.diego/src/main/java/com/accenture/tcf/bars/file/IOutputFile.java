package com.accenture.tcf.bars.file;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.accenture.tcf.bars.controller.FileProcessor;
import com.accenture.tcf.bars.domain.Record;

public interface IOutputFile {

	public void writeFile(List<Record> record);
	public void setFile (File file);
	public File getFile();


}

