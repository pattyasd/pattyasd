package com.accenture.tcf.bars.file;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.accenture.tcf.bars.domain.Record;

public class XMLOutputFileImpl extends AbstractOutputFile{

	// TODO Auto-generated method stub

			/*BarsWriteXMLUtilsInterface x = new BarsWriteXmlUtils();

			Document doc = x.createXMLDocument();

			Element rootElement = x.createDocumentElement(doc, "BARS");

			for(int i = 0; i < records.size(); i++) {
				Element request = x.createChildElement(doc, rootElement, "request");
				x.createElementTextNode(doc, request, "billing-cycle", Integer.toString(records.get(i).getBillingCycle()));
				x.createElementTextNode(doc, request, "start-date", records.get(i).getStartDate().toString());
				x.createElementTextNode(doc, request, "end-date", records.get(i).getEndDate().toString());
				x.createElementTextNode(doc, request, "first-name", records.get(i).getCustomerFirstName());
				x.createElementTextNode(doc, request, "last-name", records.get(i).getCustomerLastName());
				x.createElementTextNode(doc, request, "amount", Double.toString(records.get(i).getAmount()));
			}

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	        String time = dtf.format(LocalDateTime.now());
	        time = time.trim();
	        time = time.replaceAll("/", "");
	        time = time.replaceAll(":", "");
	        time = time.replaceAll(" ", "_");

			x.transformToXML(doc, "C:\\bars\\BARS_Report-" + time + ".xml");*/

			/*try {
		         DocumentBuilderFactory dbFactory =
		         DocumentBuilderFactory.newInstance();
		         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		         Document doc = dBuilder.newDocument();

		         // BARS element
		         Element rootElement = doc.createElement("BARS");
		         doc.appendChild(rootElement);

		         for(int i = 0; i < records.size(); i++) {
		        	 // request element
			         Element requestxml = doc.createElement("request");
			         rootElement.appendChild(requestxml);

			         // billing-cycle element
			         Element billing = doc.createElement("billing-cycle");
			         billing.appendChild(doc.createTextNode(Integer.toString(records.get(i).getBillingCycle())));
			         requestxml.appendChild(billing);

			         //start-date element
			         Element start = doc.createElement("start-date");
			         start.appendChild(doc.createTextNode(records.get(i).getStartDate().toString()));
			         requestxml.appendChild(start);

			         //end-date element
			         Element end = doc.createElement("end-date");
			         end.appendChild(doc.createTextNode(records.get(i).getEndDate().toString()));
			         requestxml.appendChild(end);

			         //first-name element
			         Element fName = doc.createElement("first-name");
			         fName.appendChild(doc.createTextNode(records.get(i).getCustomerFirstName()));
			         requestxml.appendChild(fName);

			         //last-name element
			         Element lName = doc.createElement("last-name");
			         lName.appendChild(doc.createTextNode(records.get(i).getCustomerLastName()));
			         requestxml.appendChild(lName);

			         //amount element
			         Element amount = doc.createElement("amount");
			         amount.appendChild(doc.createTextNode(Double.toString(records.get(i).getAmount())));
			         requestxml.appendChild(amount);
		         }

		         // write the content into xml file
		         TransformerFactory transformerFactory = TransformerFactory.newInstance();
		         Transformer transformer = transformerFactory.newTransformer();
		         transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		         transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
		         DOMSource source = new DOMSource(doc);
		         DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		         String time = dtf.format(LocalDateTime.now());
		         time = time.trim();
		         time = time.replaceAll("/", "");
		         time = time.replaceAll(":", "");
		         time = time.replaceAll(" ", "_");
		         System.out.println(time);
		         StreamResult result = new StreamResult(new File("C:\\bars\\BARS_Report-" + time + ".xml"));
		         transformer.transform(source, result);

		         // Output to console for testing
		         StreamResult consoleResult = new StreamResult(System.out);
		         transformer.transform(source, consoleResult);
		      } catch (Exception e) {
		         e.printStackTrace();
		      }
		}*/

	public void setFile(File file) {
		// TODO Auto-generated method stub
		super.setFile(file);
	}

	public File getFile() {
		// TODO Auto-generated method stub
		return super.getFile();
	}

	public void writeFile(List<Record> record) {
		// TODO Auto-generated method stub

	}
}

