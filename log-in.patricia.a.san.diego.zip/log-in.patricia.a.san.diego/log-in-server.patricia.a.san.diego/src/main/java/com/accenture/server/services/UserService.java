package com.accenture.server.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.server.domain.User;
import com.accenture.server.domain.UserRepository;

@Path("/userservice")
public class UserService {

	@Autowired
	private UserRepository userrepo;

	// http://localhost:8082/userservice/registeruser
	@POST
	@Path("/registeruser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response register(String user) throws JSONException {
		JSONObject json = new JSONObject(user);
		User usertable = new User();
		usertable.setFirstname(json.getString("firstname"));
		usertable.setLastname(json.getString("lastname"));
		usertable.setUsername(json.getString("username"));
		usertable.setPassword(json.getString("password"));
		usertable.setAdmin(json.getBoolean("admin"));

		userrepo.save(usertable);
		JSONObject jsonresponse = new JSONObject();

		jsonresponse.put("Info", "Registered Successfully");

		return Response.status(200).entity(jsonresponse.toString())
				.type(MediaType.APPLICATION_JSON).build();

	}

	// http://localhost:8082/userservice/viewAll

	@POST
	@Path("/viewAll")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response viewAll() throws JSONException {
		JSONObject json = null;
		JSONArray jarr = new JSONArray();
		List<User> userList = userrepo.findAll();
		for (User userinfo : userList) {
			json = new JSONObject();
			json.put("id", userinfo.getId());
			json.put("firstname", userinfo.getFirstname());
			json.put("lastname", userinfo.getLastname());
			json.put("username", userinfo.getUsername());
			json.put("admin", userinfo.isAdmin());
			jarr.put(json);

		}

		return Response.status(200).entity(jarr.toString())
				.type(MediaType.APPLICATION_JSON).build();

	}

	// http://localhost:8082/userservice/deleteUser
	@POST
	@Path("/deleteUser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response delete(String id) throws JSONException {
		JSONObject json = new JSONObject(id);

		userrepo.delete(Long.parseLong(json.getString("id")));

		JSONObject jsonresponse = new JSONObject();

		jsonresponse.put("Info", "Request Completed");

		return Response.status(200).entity(jsonresponse.toString())
				.type(MediaType.APPLICATION_JSON).build();

	}

	// http://localhost:8082/userservice/update
	@POST
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response update(String user) throws JSONException {
		JSONObject json = new JSONObject(user);

		userrepo.updateQuery(Long.parseLong(json.getString("id")),
				json.getString("firstname"),
				json.getString("lastname"),
				json.getString("password"),
				json.getString("username"));
		System.out.println(json.getString("username"));
		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put("Info", "Updated information!");

		return Response.status(200).entity(jsonResponse.toString())
				.type(MediaType.APPLICATION_JSON).build();
	}

	// http://localhost:8082/userservice/searchUser?username=

	@POST
	@Path("/searchUser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response ifExisting(@QueryParam("username") String username)
			throws JSONException {
		User user = userrepo.findIfExisting(username);

		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put("username", user.getUsername());

		return Response.status(200).entity(jsonResponse.toString())
				.type(MediaType.APPLICATION_JSON).build();
	}

}
