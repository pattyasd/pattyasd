package com.accenture.server.domain;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "user", path = "user")
public interface UserRepository extends JpaRepository<User, Long> {

	@Query("Select u from User u where u.username = ?1 and u.password = ?2")
	User findByUsernameAndPassword(String username, String password);

	@Query("Select u from User u where u.admin = ?1 and u.username = ?2 and u.password = ?3")
	User findByRole(boolean usertype, String username, String password);

	@Query("Select u from User u where u.username = ?1")
	User findIfExisting(String username);

	@Transactional
	@Modifying
	@Query("Update User u set u.firstname = ?2, u.lastname = ?3, u.password = ?4, u.username = ?5 where u.id = ?1")
	void updateQuery(Long id, String firstname, String lastname,
			String password, String username);

	/*	@Query("Select u.username, u.admin from User u")
	List<User> findAllQuery();*/

	/*	@Query("Select u from User u where u.id = ?1")
	User findDataById(Long id);*/
}
