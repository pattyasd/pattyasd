package com.accenture.client.controller;

import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
@EnableCircuitBreaker
@Controller
public class ClientController {
	@Autowired
	private Login login;

	 /*@Bean
	  public RestTemplate rest(RestTemplateBuilder builder) {
	    return builder.build();
	  }*/

	@RequestMapping("/")
	public ModelAndView userLogin() {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("Login");
		return mv;
	}

	@RequestMapping("/login")
	public ModelAndView View(@RequestParam(value = "username") String username,
			@RequestParam(value = "password") String password, Model model) {

		return login.userValidation(username, password);

	}

	// DELETE
	@RequestMapping("/deleteUser")
	public String redirectToDelete() {
		return "DeleteUser";
	}

	@RequestMapping("/deleteRequest")
	public String deleteUser(@RequestParam String selectUser)
			throws JSONException {

		JSONObject json = new JSONObject();
		String temp1 = selectUser.replaceAll(" ", "");
		String[] temp2 = temp1.split("-");
		json.put("id", temp2[0]);

		Client client = new Client();

		WebResource wr = client
				.resource("http://localhost:8082/userservice/deleteUser");
		ClientResponse response = wr.type(MediaType.APPLICATION_JSON).post(
				ClientResponse.class, json.toString());
		@SuppressWarnings("unused")
		String restStr = response.getEntity(String.class);

		return "redirect:/homeadmin";
	}

	// INSERT USER
	@RequestMapping("/insertUser")
	public String redirectToInput() {
		return "InsertUser"; // html page for insert
	}

	@RequestMapping("/insert")
	public String registerUser(@RequestParam String firstname,
			@RequestParam String lastname, @RequestParam String password,
			@RequestParam String role, @RequestParam String username)
			throws JSONException {

		boolean usertype;
		if (role.equalsIgnoreCase("Yes")) {
			usertype = true;
		} else {
			usertype = false;
		}

		JSONObject json = new JSONObject();
		json.put("firstname", firstname);
		json.put("lastname", lastname);
		json.put("password", password);
		json.put("admin", usertype);
		json.put("username", username);

		Client client = new Client();

		WebResource wr = client
				.resource("http://localhost:8082/userservice/registeruser");
		ClientResponse response = wr.type(MediaType.APPLICATION_JSON).post(
				ClientResponse.class, json.toString());
		String restString = response.getEntity(String.class);

		return "redirect:/homeadmin";
	}

	// UPDATE
	@RequestMapping("updateUser")
	public String redirectToUpdate() {
		return "UpdateUser";
	}

	@RequestMapping("/updateRequest")
	public String updateUser(@RequestParam String selectUser,
			@RequestParam String firstname, @RequestParam String lastname,
			@RequestParam String username, @RequestParam String password)
			throws JSONException {
		JSONObject json = new JSONObject();

		String temp1 = selectUser.replaceAll(" ", "");
		String[] temp2 = temp1.split("-");

		json.put("id", temp2[0]);
		json.put("firstname", firstname);
		json.put("lastname", lastname);
		json.put("username", username);
		json.put("password", password);

		Client client = new Client();

		WebResource wr = client
				.resource("http://localhost:8082/userservice/update");
		ClientResponse response = wr.type(MediaType.APPLICATION_JSON).post(
				ClientResponse.class, json.toString());
		@SuppressWarnings("unused")
		String restStr = response.getEntity(String.class);

		return "redirect:/homeadmin";
	}

}
